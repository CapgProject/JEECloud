// 
// Decompiled by Procyon v0.5.36
// 

package com.cg.jdbclab.ui;

import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import com.cg.jdbclab.Exception.MyException;
import java.math.BigInteger;
import java.math.BigDecimal;
import com.cg.jdbclab.dto.Book;
import java.util.Scanner;
import com.cg.jdbclab.dao.DaoImpl;
import com.cg.jdbclab.dao.Dao;

public class Application
{
    private static Dao dao;
    
    static {
        Application.dao = new DaoImpl();
    }
    
    public static void main(final String[] args) {
        final Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("Enter your choice:");
            System.out.println("1 to add book, 2 to list all books, 3 to list all books of a specific author, 4 to exit");
            choice = scanner.nextInt();
        } while (choice != 4);
        Book book = new Book();
        book.setBookName("c#");
        book.setBookPrice(new BigDecimal(500));
        book.setAuthorId(BigInteger.valueOf(2L));
        try {
            book = Application.dao.addBook(book);
            if (book != null) {
                System.out.println("Book added successfully :" + book);
            }
            else {
                System.out.println("Book not added :" + book);
            }
        }
        catch (MyException e) {
            System.out.println(e.getMessage());
        }
        final List<Book> bookList = Application.dao.listAllBooks();
        if (bookList != null) {
            bookList.forEach(System.out::println);
        }
        else {
            System.out.println("No Record Found!!");
        }
        final List<Book> list = Application.dao.authorBooks(book);
        for (final Book book2 : list) {
            System.out.println("The books found are " + book.getBookName());
        }
    }
}
