// 
// Decompiled by Procyon v0.5.36
// 

package com.cg.jdbclab.util;

import java.io.InputStream;
import java.io.FileInputStream;
import com.cg.jdbclab.Exception.MyException;
import java.sql.DriverManager;
import java.util.Properties;
import org.apache.log4j.PropertyConfigurator;
import java.sql.Connection;
import org.apache.log4j.Logger;

public class DBUtil
{
    private static Logger myLogger;
    private static Connection connection;
    
    static {
        final Properties props = System.getProperties();
        final String userDir = String.valueOf(props.getProperty("user.dir")) + "/src/main/resources/";
        System.out.println("Current working directory is " + userDir);
        PropertyConfigurator.configure(String.valueOf(userDir) + "log4j.properties");
        DBUtil.myLogger = Logger.getLogger("DBUtil.class");
    }
    
    public static Connection getConnection() throws MyException {
        try {
            final Properties prop = loadProp();
            final String url = prop.getProperty("url");
            final String username = prop.getProperty("user");
            final String password = prop.getProperty("password");
            DBUtil.connection = DriverManager.getConnection(url, username, password);
            if (DBUtil.connection == null) {
                throw new MyException("sorry!!! Something went wrong with the connection");
            }
            DBUtil.myLogger.info((Object)("connection Obtained! : " + DBUtil.connection));
        }
        catch (Exception e) {
            throw new MyException(e.getMessage());
        }
        return DBUtil.connection;
    }
    
    private static Properties loadProp() throws MyException {
        final Properties props = System.getProperties();
        final String userDir = String.valueOf(props.getProperty("user.dir")) + "/src/main/resources/";
        final Properties myProp = new Properties();
        try {
            Throwable t = null;
            try {
                final FileInputStream fis = new FileInputStream(String.valueOf(userDir) + "jdbc.properties");
                try {
                    myProp.load(fis);
                    DBUtil.myLogger.info((Object)"Property File loaded : ");
                }
                finally {
                    if (fis != null) {
                        fis.close();
                    }
                }
            }
            finally {
                if (t == null) {
                    final Throwable exception;
                    t = exception;
                }
                else {
                    final Throwable exception;
                    if (t != exception) {
                        t.addSuppressed(exception);
                    }
                }
            }
        }
        catch (Exception e) {
            DBUtil.myLogger.error((Object)"Property File Not loaded");
            throw new MyException(e.getMessage());
        }
        return myProp;
    }
    
    public static void closeConnection() throws MyException {
        try {
            if (DBUtil.connection != null) {
                DBUtil.connection.close();
                DBUtil.myLogger.error((Object)"Closing Connection");
            }
            else {
                DBUtil.myLogger.error((Object)"Connection already closed");
            }
        }
        catch (Exception e) {
            DBUtil.myLogger.error((Object)"Connection already closed");
            throw new MyException(e.getMessage());
        }
    }
}
