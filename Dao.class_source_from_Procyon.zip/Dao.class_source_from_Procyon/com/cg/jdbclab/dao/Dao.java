// 
// Decompiled by Procyon v0.5.36
// 

package com.cg.jdbclab.dao;

import java.util.List;
import com.cg.jdbclab.Exception.MyException;
import com.cg.jdbclab.dto.Book;

public interface Dao
{
    Book addBook(final Book p0) throws MyException;
    
    List<Book> listAllBooks();
    
    List<Book> authorBooks(final Book p0);
}
