// 
// Decompiled by Procyon v0.5.36
// 

package com.cg.jdbclab.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.math.BigInteger;
import com.cg.jdbclab.dto.Book;
import java.util.Properties;
import com.cg.jdbclab.Exception.MyException;
import com.cg.jdbclab.util.DBUtil;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.Logger;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;

public class DaoImpl implements Dao
{
    private static Connection connection;
    private PreparedStatement ps;
    private ResultSet rs;
    private static Logger myLogger;
    
    static {
        final Properties props = System.getProperties();
        final String userDir = String.valueOf(props.getProperty("user.dir")) + "/src/main/resources/";
        System.out.println("Current working directory is " + userDir);
        PropertyConfigurator.configure(String.valueOf(userDir) + "log4j.properties");
        DaoImpl.myLogger = Logger.getLogger("DBUtil.class");
        try {
            DaoImpl.connection = DBUtil.getConnection();
            DaoImpl.myLogger.info((Object)"Connection Obtained!!");
        }
        catch (MyException e) {
            DaoImpl.myLogger.error((Object)("Connection Not Obtained at EmployeeDao : " + e));
        }
    }
    
    public Book addBook(final Book book) throws MyException {
        final String sql = "Insert into book(book_name,book_price,author_Id) values (?,?,?)";
        try {
            (this.ps = DaoImpl.connection.prepareStatement(sql)).setString(1, book.getBookName());
            this.ps.setBigDecimal(2, book.getBookPrice());
            this.ps.setLong(3, book.getAuthorId().longValue());
            final int noOfRec = this.ps.executeUpdate();
            BigInteger generatedId = BigInteger.valueOf(0L);
            this.rs = this.ps.getGeneratedKeys();
            if (this.rs.next()) {
                generatedId = BigInteger.valueOf(this.rs.getLong(1));
                System.out.println("Auto generated Id " + generatedId);
            }
            book.setBookId(generatedId);
        }
        catch (SQLIntegrityConstraintViolationException e3) {
            throw new MyException("The entered author does not exist");
        }
        catch (SQLException e) {
            DaoImpl.myLogger.error((Object)("Error at addBook Dao method : " + e));
            System.out.println("Error at addBook Dao method : " + e);
        }
        finally {
            if (this.ps != null) {
                try {
                    this.ps.close();
                }
                catch (SQLException e2) {
                    System.out.println("Error at addBook Dao method : " + e2);
                }
            }
        }
        if (this.ps != null) {
            try {
                this.ps.close();
            }
            catch (SQLException e2) {
                System.out.println("Error at addBook Dao method : " + e2);
            }
        }
        return book;
    }
    
    public List<Book> listAllBooks() {
        final String sql = "select * from book";
        final List<Book> list = new ArrayList<Book>();
        try {
            this.ps = DaoImpl.connection.prepareStatement(sql);
            this.rs = this.ps.executeQuery();
            while (this.rs.next()) {
                final Book book = new Book();
                book.setBookId(BigInteger.valueOf(this.rs.getLong("book_Id")));
                book.setBookName(this.rs.getString("book_name"));
                book.setBookPrice(BigDecimal.valueOf(this.rs.getLong("book_price")));
                book.setAuthorId(BigInteger.valueOf(this.rs.getLong("author_Id")));
                list.add(book);
            }
        }
        catch (SQLException e) {
            System.out.println("Error at listAllBooks Dao method : " + e);
            if (this.ps != null) {
                try {
                    this.ps.close();
                }
                catch (SQLException e2) {
                    System.out.println("Error at listAllBooks Dao method : " + e2);
                }
                return list;
            }
            return list;
        }
        finally {
            if (this.ps != null) {
                try {
                    this.ps.close();
                }
                catch (SQLException e2) {
                    System.out.println("Error at listAllBooks Dao method : " + e2);
                }
            }
        }
        if (this.ps != null) {
            try {
                this.ps.close();
            }
            catch (SQLException e2) {
                System.out.println("Error at listAllBooks Dao method : " + e2);
            }
        }
        return list;
    }
    
    public List<Book> authorBooks(final Book book) {
        final List<Book> authorList = new ArrayList<Book>();
        final String sql = "select book_name from book where author_Id = ?";
        try {
            (this.ps = DaoImpl.connection.prepareStatement(sql)).setLong(1, book.getAuthorId().longValue());
            this.rs = this.ps.executeQuery();
            while (this.rs.next()) {
                final Book authorBook = new Book();
                authorBook.setBookId(BigInteger.valueOf(this.rs.getLong("book_Id")));
                authorBook.setBookName(this.rs.getString("book_name"));
                authorList.add(book);
            }
        }
        catch (SQLException e) {
            System.out.println("Error at authorBooks Dao method : " + e);
            if (this.ps != null) {
                try {
                    this.ps.close();
                }
                catch (SQLException e2) {
                    System.out.println("Error at authorBooks Dao method : " + e2);
                }
                return authorList;
            }
            return authorList;
        }
        finally {
            if (this.ps != null) {
                try {
                    this.ps.close();
                }
                catch (SQLException e2) {
                    System.out.println("Error at authorBooks Dao method : " + e2);
                }
            }
        }
        if (this.ps != null) {
            try {
                this.ps.close();
            }
            catch (SQLException e2) {
                System.out.println("Error at authorBooks Dao method : " + e2);
            }
        }
        return authorList;
    }
}
