// 
// Decompiled by Procyon v0.5.36
// 

package com.cg.jdbclab.Exception;

public class MyException extends Exception
{
    public MyException() {
    }
    
    public MyException(final String s) {
        super(s);
    }
}
